import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import model from '../assets/models/water-random-forest.json';
import { useColors } from '@/hooks/useColors';

type Tree = {
  left: number[];
  right: number[];
  feature: number[];
  threshold: number[];
  values: number[][];
};
type ModelBundle = {
  trees: Tree[];
  metrics: { test_accuracy: number; test_balanced_accuracy: number; test_size: number };
  source: string;
};
const forest = model as ModelBundle;
const featureKeys = ['ph', 'hardness', 'solids', 'chloramines', 'sulfate', 'conductivity', 'organic_carbon', 'trihalomethanes', 'turbidity'] as const;
const featureLabels = ['pH', 'Hardness', 'TDS', 'Chloramines', 'Sulfate', 'Conductivity', 'Organic carbon', 'Trihalomethanes', 'Turbidity'];
const units = ['pH', 'mg/L', 'ppm', 'mg/L', 'mg/L', 'μS/cm', 'mg/L', 'μg/L', 'NTU'];

function estimatePotable(values: number[]) {
  const classTotals = [0, 0];
  for (const tree of forest.trees) {
    let node = 0;
    while (tree.left[node] !== tree.right[node]) {
      const featureIndex = tree.feature[node];
      node = values[featureIndex] <= tree.threshold[node] ? tree.left[node] : tree.right[node];
    }
    const distribution = tree.values[node];
    const sum = distribution[0] + distribution[1];
    if (sum > 0) {
      classTotals[0] += distribution[0] / sum;
      classTotals[1] += distribution[1] / sum;
    }
  }
  return classTotals[1] / forest.trees.length;
}

export default function PredictionScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<Record<(typeof featureKeys)[number], string>>();
  const values = featureKeys.map((key) => Number(params[key]));
  const valid = values.length === 9 && values.every(Number.isFinite) && forest.trees.length > 0;
  const potableProbability = valid ? estimatePotable(values) : 0;
  const isPotable = potableProbability >= 0.5;
  const percent = Math.round(potableProbability * 100);
  const topInset = Math.max(insets.top, Platform.OS === 'web' ? 67 : 0);
  const bottomInset = Math.max(insets.bottom, Platform.OS === 'web' ? 34 : 0);

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <StatusBar style="dark" />
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: topInset + 12, paddingBottom: bottomInset + 26 }]}
        showsVerticalScrollIndicator={false}
      >
        <Pressable accessibilityRole="button" testID="back-measurements" onPress={() => router.back()} style={styles.backButton}>
          <Feather name="arrow-left" size={18} color={colors.foreground} />
          <Text style={[styles.backText, { color: colors.foreground }]}>Measurements</Text>
        </Pressable>

        <Text style={[styles.eyebrow, { color: colors.primary }]}>MODEL OUTPUT · 02 / 02</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Sample estimate</Text>
        {!valid ? (
          <View style={[styles.warningCard, { borderColor: colors.border, backgroundColor: colors.card }]}>
            <Feather name="alert-circle" size={20} color={colors.destructive} />
            <Text style={[styles.warningText, { color: colors.foreground }]}>This result could not be calculated. Return to the measurement form and enter all nine values.</Text>
          </View>
        ) : (
          <>
            <View style={[styles.resultCard, { backgroundColor: isPotable ? '#e2f2ed' : '#fff0e9' }]}>
              <View style={styles.resultHeader}>
                <View style={[styles.resultIcon, { backgroundColor: isPotable ? '#c7e7dc' : '#f8daca' }]}>
                  <Feather name={isPotable ? 'check' : 'alert-triangle'} size={20} color={isPotable ? '#1d725d' : '#a34c31'} />
                </View>
                <Text style={[styles.resultOverline, { color: isPotable ? '#1d725d' : '#a34c31' }]}>PREDICTED CLASS</Text>
              </View>
              <Text style={[styles.resultTitle, { color: colors.foreground }]}>{isPotable ? 'Potable' : 'Non-potable'}</Text>
              <Text style={[styles.resultDescription, { color: colors.mutedForeground }]}>
                {isPotable
                  ? 'The model classifies this sample as potable.'
                  : 'The model classifies this sample as non-potable.'}
              </Text>
              <View style={styles.probabilityRow}>
                <View>
                  <Text style={[styles.probabilityLabel, { color: colors.mutedForeground }]}>MODEL-ESTIMATED POTABLE PROBABILITY</Text>
                  <Text style={[styles.probabilityValue, { color: colors.foreground }]}>{percent}%</Text>
                </View>
                <View style={[styles.probabilityRing, { borderColor: isPotable ? '#74bba5' : '#d18b6c' }]}>
                  <Feather name="droplet" size={21} color={isPotable ? '#1d725d' : '#a34c31'} />
                </View>
              </View>
              <View style={styles.track}>
                <View style={[styles.fill, { width: `${percent}%`, backgroundColor: isPotable ? '#27856d' : '#bd6644' }]} />
              </View>
            </View>

            <View style={[styles.disclaimer, { backgroundColor: '#fff8e8', borderColor: '#f0dfb9' }]}>
              <Feather name="shield" size={19} color="#8f6827" />
              <View style={styles.disclaimerCopy}>
                <Text style={styles.disclaimerTitle}>Important safety note</Text>
                <Text style={styles.disclaimerText}>
                  This is a machine-learning estimate, not a safety certification. It cannot detect every contaminant or replace testing by a certified laboratory. Do not use this result alone to decide whether water is safe to drink.
                </Text>
              </View>
            </View>

            <View style={styles.measurementsHeader}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Sample values</Text>
              <Text style={[styles.sectionNote, { color: colors.mutedForeground }]}>9 MEASUREMENTS</Text>
            </View>
            <View style={[styles.valuesCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              {featureKeys.map((key, index) => (
                <View key={key} style={[styles.valueRow, index < featureKeys.length - 1 && { borderBottomColor: colors.border, borderBottomWidth: StyleSheet.hairlineWidth }]}>
                  <Text style={[styles.valueLabel, { color: colors.mutedForeground }]}>{featureLabels[index]}</Text>
                  <Text style={[styles.valueText, { color: colors.foreground }]}>{values[index].toLocaleString(undefined, { maximumFractionDigits: 3 })} <Text style={[styles.valueUnit, { color: colors.mutedForeground }]}>{units[index]}</Text></Text>
                </View>
              ))}
            </View>
          </>
        )}

        <Pressable
          accessibilityRole="button"
          testID="new-sample"
          onPress={() => router.replace('/measurements')}
          style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary, opacity: pressed ? 0.88 : 1 }]}
        >
          <Feather name="refresh-cw" size={17} color="#ffffff" />
          <Text style={styles.primaryButtonText}>Test another sample</Text>
        </Pressable>
        <Text style={[styles.modelNote, { color: colors.mutedForeground }]}>
          Held-out test performance: {Math.round(forest.metrics.test_accuracy * 100)}% accuracy across {forest.metrics.test_size.toLocaleString()} samples. Model-estimated probability is not a calibrated safety guarantee.
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 22, maxWidth: 560, width: '100%', alignSelf: 'center' },
  backButton: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', paddingVertical: 8, paddingRight: 12, gap: 8, marginBottom: 20 },
  backText: { fontSize: 13, fontWeight: '600' },
  eyebrow: { fontSize: 9, fontWeight: '700', letterSpacing: 1.3, marginBottom: 9 },
  title: { fontSize: 29, fontWeight: '700', letterSpacing: -0.8, marginBottom: 20 },
  resultCard: { borderRadius: 22, padding: 20 },
  resultHeader: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  resultIcon: { width: 35, height: 35, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  resultOverline: { fontSize: 9, fontWeight: '700', letterSpacing: 1.2 },
  resultTitle: { fontSize: 32, fontWeight: '700', letterSpacing: -0.9, marginTop: 16 },
  resultDescription: { fontSize: 13, lineHeight: 19, marginTop: 4 },
  probabilityRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 24 },
  probabilityLabel: { fontSize: 8, fontWeight: '700', letterSpacing: 0.6 },
  probabilityValue: { fontSize: 35, fontWeight: '700', letterSpacing: -1, marginTop: 3 },
  probabilityRing: { width: 48, height: 48, borderRadius: 24, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  track: { height: 7, backgroundColor: '#ffffffa0', borderRadius: 8, overflow: 'hidden', marginTop: 10 },
  fill: { height: '100%', borderRadius: 8 },
  disclaimer: { flexDirection: 'row', gap: 11, borderWidth: 1, borderRadius: 17, padding: 15, marginTop: 14 },
  disclaimerCopy: { flex: 1 },
  disclaimerTitle: { color: '#6d501e', fontSize: 12, fontWeight: '700', marginBottom: 5 },
  disclaimerText: { color: '#665c47', fontSize: 11, lineHeight: 17 },
  measurementsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 26, marginBottom: 11 },
  sectionTitle: { fontSize: 16, fontWeight: '700' },
  sectionNote: { fontSize: 8, fontWeight: '700', letterSpacing: 1 },
  valuesCard: { borderWidth: 1, borderRadius: 17, paddingHorizontal: 14 },
  valueRow: { minHeight: 42, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  valueLabel: { flex: 1, fontSize: 11 },
  valueText: { fontSize: 12, fontWeight: '600', textAlign: 'right' },
  valueUnit: { fontSize: 9, fontWeight: '400' },
  warningCard: { borderWidth: 1, borderRadius: 17, padding: 17, flexDirection: 'row', alignItems: 'flex-start', gap: 11 },
  warningText: { flex: 1, fontSize: 13, lineHeight: 20 },
  primaryButton: { minHeight: 55, borderRadius: 17, paddingHorizontal: 18, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 10, marginTop: 20 },
  primaryButtonText: { color: '#ffffff', fontSize: 14, fontWeight: '700' },
  modelNote: { fontSize: 10, lineHeight: 16, textAlign: 'center', marginTop: 12, paddingHorizontal: 8 },
});
