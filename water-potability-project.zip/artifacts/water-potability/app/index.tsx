import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const webTop = Platform.OS === 'web' ? 67 : 0;
  const webBottom = Platform.OS === 'web' ? 34 : 0;

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <StatusBar style="dark" />
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: Math.max(insets.top, webTop) + 18, paddingBottom: Math.max(insets.bottom, webBottom) + 28 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.brandRow}>
          <View style={[styles.brandMark, { backgroundColor: colors.primary }]}>
            <Feather name="droplet" size={20} color={colors.primaryForeground} />
          </View>
          <Text style={[styles.brand, { color: colors.foreground }]}>AQUA / CHECK</Text>
          <View style={styles.localPill}>
            <View style={styles.onlineDot} />
            <Text style={styles.localText}>ON-DEVICE</Text>
          </View>
        </View>

        <View style={styles.hero}>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>WATER QUALITY SCREENING</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>
            Know what’s{'\n'}in your water.
          </Text>
          <Text style={[styles.intro, { color: colors.mutedForeground }]}>
            Enter a sample’s physical and chemical measurements for a machine-learning estimate of potability.
          </Text>
        </View>

        <View style={[styles.featureCard, { backgroundColor: '#123f47' }]}>
          <View style={styles.featureTop}>
            <View style={styles.featureIcon}>
              <Feather name="activity" size={19} color="#b7e4dc" />
            </View>
            <Text style={styles.featureTag}>RANDOM FOREST MODEL</Text>
          </View>
          <Text style={styles.featureTitle}>Nine signals.{'\n'}One informed estimate.</Text>
          <Text style={styles.featureBody}>
            The model compares your measurements with patterns learned from a labeled water-quality dataset.
          </Text>
          <View style={styles.featureRule} />
          <View style={styles.featureFooter}>
            <Text style={styles.featureFooterText}>pH · minerals · solids · contaminants</Text>
            <Feather name="arrow-up-right" size={17} color="#b7e4dc" />
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>A quick screening</Text>
          <Text style={[styles.sectionNote, { color: colors.mutedForeground }]}>3 STEPS</Text>
        </View>
        <View style={styles.steps}>
          {[
            ['01', 'Measure', 'Add nine water-quality values'],
            ['02', 'Analyze', 'Run the model on your device'],
            ['03', 'Review', 'See the class and estimate'],
          ].map(([number, title, description], index) => (
            <View key={number} style={styles.stepRow}>
              <View style={[styles.stepNumber, { backgroundColor: colors.accent }]}>
                <Text style={[styles.stepNumberText, { color: colors.primary }]}>{number}</Text>
              </View>
              <View style={styles.stepCopy}>
                <Text style={[styles.stepTitle, { color: colors.foreground }]}>{title}</Text>
                <Text style={[styles.stepDescription, { color: colors.mutedForeground }]}>{description}</Text>
              </View>
              {index < 2 && <View style={[styles.stepLine, { backgroundColor: colors.border }]} />}
            </View>
          ))}
        </View>

        <Pressable
          accessibilityRole="button"
          testID="start-prediction"
          onPress={() => router.push('/measurements')}
          style={({ pressed }) => [
            styles.primaryButton,
            { backgroundColor: colors.primary, opacity: pressed ? 0.88 : 1 },
          ]}
        >
          <Text style={styles.primaryButtonText}>Start a prediction</Text>
          <Feather name="arrow-right" size={19} color="#ffffff" />
        </Pressable>
        <Text style={[styles.safetyNote, { color: colors.mutedForeground }]}>
          Screening only. A model cannot confirm that water is safe to drink.
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 24, maxWidth: 560, width: '100%', alignSelf: 'center' },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  brandMark: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  brand: { fontSize: 12, fontWeight: '700', letterSpacing: 1.5 },
  localPill: { marginLeft: 'auto', flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 7, paddingHorizontal: 10, borderRadius: 20, backgroundColor: '#e4f1ef' },
  onlineDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#278275' },
  localText: { color: '#386d69', fontSize: 9, fontWeight: '700', letterSpacing: 1 },
  hero: { marginTop: 40, marginBottom: 26 },
  eyebrow: { fontSize: 10, fontWeight: '700', letterSpacing: 1.45, marginBottom: 12 },
  title: { fontSize: 42, lineHeight: 48, fontWeight: '700', letterSpacing: -1.5 },
  intro: { fontSize: 15, lineHeight: 23, marginTop: 14, maxWidth: 390 },
  featureCard: { borderRadius: 24, padding: 22, overflow: 'hidden' },
  featureTop: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  featureIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: '#245a60', alignItems: 'center', justifyContent: 'center' },
  featureTag: { color: '#b7e4dc', fontSize: 9, fontWeight: '700', letterSpacing: 1.25 },
  featureTitle: { color: '#f1fbf8', fontSize: 27, fontWeight: '600', lineHeight: 33, letterSpacing: -0.6, marginTop: 20 },
  featureBody: { color: '#c4dcda', fontSize: 13, lineHeight: 20, marginTop: 10, maxWidth: 360 },
  featureRule: { height: 1, backgroundColor: '#38676b', marginTop: 20, marginBottom: 14 },
  featureFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  featureFooterText: { color: '#b7e4dc', fontSize: 10, letterSpacing: 0.25 },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 32, marginBottom: 17 },
  sectionTitle: { fontSize: 18, fontWeight: '700', letterSpacing: -0.3 },
  sectionNote: { fontSize: 9, fontWeight: '700', letterSpacing: 1.2 },
  steps: { gap: 0, marginBottom: 26 },
  stepRow: { flexDirection: 'row', alignItems: 'center', minHeight: 55, position: 'relative' },
  stepNumber: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  stepNumberText: { fontSize: 10, fontWeight: '700' },
  stepCopy: { marginLeft: 13, gap: 3 },
  stepTitle: { fontSize: 13, fontWeight: '600' },
  stepDescription: { fontSize: 11 },
  stepLine: { position: 'absolute', left: 16, top: 45, height: 10, width: 1 },
  primaryButton: { minHeight: 58, borderRadius: 18, paddingHorizontal: 20, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  primaryButtonText: { color: '#ffffff', fontSize: 15, fontWeight: '700' },
  safetyNote: { fontSize: 11, lineHeight: 17, textAlign: 'center', marginTop: 14, paddingHorizontal: 12 },
});
