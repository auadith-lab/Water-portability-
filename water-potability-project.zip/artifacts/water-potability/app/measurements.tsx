import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';

const measurements = [
  { key: 'ph', label: 'pH', detail: 'Acidity or alkalinity', unit: 'pH', placeholder: 'e.g. 7.2' },
  { key: 'hardness', label: 'Hardness', detail: 'Calcium and magnesium', unit: 'mg/L', placeholder: 'e.g. 196' },
  { key: 'solids', label: 'Total dissolved solids', detail: 'Dissolved mineral content', unit: 'ppm', placeholder: 'e.g. 18,000' },
  { key: 'chloramines', label: 'Chloramines', detail: 'Disinfectant concentration', unit: 'mg/L', placeholder: 'e.g. 7.1' },
  { key: 'sulfate', label: 'Sulfate', detail: 'Sulfate concentration', unit: 'mg/L', placeholder: 'e.g. 333' },
  { key: 'conductivity', label: 'Conductivity', detail: 'Ability to conduct electricity', unit: 'μS/cm', placeholder: 'e.g. 425' },
  { key: 'organic_carbon', label: 'Organic carbon', detail: 'Organic carbon measurement', unit: 'mg/L', placeholder: 'e.g. 14.3' },
  { key: 'trihalomethanes', label: 'Trihalomethanes', detail: 'Disinfection by-product level', unit: 'μg/L', placeholder: 'e.g. 66' },
  { key: 'turbidity', label: 'Turbidity', detail: 'Water cloudiness', unit: 'NTU', placeholder: 'e.g. 3.5' },
] as const;

type Values = Record<(typeof measurements)[number]['key'], string>;
const emptyValues = (): Values => Object.fromEntries(measurements.map((item) => [item.key, ''])) as Values;

export default function MeasurementsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [values, setValues] = useState<Values>(emptyValues);
  const [error, setError] = useState('');
  const topInset = Math.max(insets.top, Platform.OS === 'web' ? 67 : 0);
  const bottomInset = Math.max(insets.bottom, Platform.OS === 'web' ? 34 : 0);

  function submit() {
    const missing = measurements.find(({ key }) => values[key].trim() === '');
    if (missing) {
      setError(`Enter a value for ${missing.label} to continue.`);
      return;
    }
    const invalid = measurements.find(({ key }) => !Number.isFinite(Number(values[key])) || values[key].trim() === '');
    if (invalid) {
      setError(`${invalid.label} needs to be a valid number.`);
      return;
    }
    setError('');
    const params = Object.fromEntries(measurements.map(({ key }) => [key, String(Number(values[key]))]));
    router.push({ pathname: '/prediction', params });
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <StatusBar style="dark" />
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[styles.content, { paddingTop: topInset + 12, paddingBottom: bottomInset + 28 }]}
        showsVerticalScrollIndicator={false}
        bottomOffset={22}
      >
        <Pressable accessibilityRole="button" testID="back-home" onPress={() => router.back()} style={styles.backButton}>
          <Feather name="arrow-left" size={18} color={colors.foreground} />
          <Text style={[styles.backText, { color: colors.foreground }]}>Back</Text>
        </Pressable>

        <View style={styles.headingRow}>
          <View style={styles.headingCopy}>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>SAMPLE INPUT · 01 / 02</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>Water measurements</Text>
          </View>
          <View style={[styles.countPill, { backgroundColor: colors.accent }]}>
            <Text style={[styles.countText, { color: colors.primary }]}>09</Text>
          </View>
        </View>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Enter values from your lab report. Use the units shown; all nine fields are required.
        </Text>

        <View style={styles.form}>
          {measurements.map((item, index) => (
            <View key={item.key} style={[styles.fieldCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.fieldTop}>
                <View style={[styles.indexDot, { backgroundColor: colors.accent }]}>
                  <Text style={[styles.indexText, { color: colors.primary }]}>{String(index + 1).padStart(2, '0')}</Text>
                </View>
                <View style={styles.fieldLabelGroup}>
                  <Text style={[styles.label, { color: colors.foreground }]}>{item.label}</Text>
                  <Text style={[styles.detail, { color: colors.mutedForeground }]}>{item.detail}</Text>
                </View>
                <Text style={[styles.unit, { color: colors.mutedForeground }]}>{item.unit}</Text>
              </View>
              <TextInput
                accessibilityLabel={`${item.label}, ${item.unit}`}
                testID={`measurement-${item.key}`}
                value={values[item.key]}
                onChangeText={(text) => {
                  setValues((current) => ({ ...current, [item.key]: text.replace(',', '.') }));
                  if (error) setError('');
                }}
                keyboardType="decimal-pad"
                inputMode="decimal"
                placeholder={item.placeholder}
                placeholderTextColor={colors.mutedForeground}
                style={[styles.input, { color: colors.foreground, borderColor: colors.input, backgroundColor: colors.background }]}
              />
            </View>
          ))}
        </View>

        {!!error && (
          <View accessibilityRole="alert" style={[styles.errorBox, { backgroundColor: '#fff0ee' }]}>
            <Feather name="alert-circle" size={16} color={colors.destructive} />
            <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
          </View>
        )}

        <Pressable
          accessibilityRole="button"
          testID="analyze-sample"
          onPress={submit}
          style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary, opacity: pressed ? 0.88 : 1 }]}
        >
          <Text style={styles.primaryButtonText}>Analyze sample</Text>
          <Feather name="arrow-right" size={19} color="#ffffff" />
        </Pressable>
        <Text style={[styles.footnote, { color: colors.mutedForeground }]}>
          Values outside the model’s training range may be less reliable.
        </Text>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 22, maxWidth: 560, width: '100%', alignSelf: 'center' },
  backButton: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', paddingVertical: 8, paddingRight: 12, gap: 8 },
  backText: { fontSize: 13, fontWeight: '600' },
  headingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 20 },
  headingCopy: { flex: 1 },
  eyebrow: { fontSize: 9, fontWeight: '700', letterSpacing: 1.3, marginBottom: 9 },
  title: { fontSize: 27, fontWeight: '700', letterSpacing: -0.8 },
  countPill: { width: 42, height: 42, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  countText: { fontSize: 13, fontWeight: '700', letterSpacing: 0.4 },
  subtitle: { fontSize: 13, lineHeight: 20, marginTop: 9, marginBottom: 18 },
  form: { gap: 10 },
  fieldCard: { borderWidth: 1, borderRadius: 18, padding: 14 },
  fieldTop: { flexDirection: 'row', alignItems: 'center' },
  indexDot: { width: 29, height: 29, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  indexText: { fontSize: 9, fontWeight: '700' },
  fieldLabelGroup: { marginLeft: 10, flex: 1, gap: 3 },
  label: { fontSize: 13, fontWeight: '600' },
  detail: { fontSize: 10 },
  unit: { fontSize: 10, fontWeight: '600', marginLeft: 8 },
  input: { borderWidth: 1, borderRadius: 12, minHeight: 45, paddingHorizontal: 13, marginTop: 12, fontSize: 14 },
  errorBox: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12, borderRadius: 12, marginTop: 13 },
  errorText: { flex: 1, fontSize: 12, fontWeight: '500' },
  primaryButton: { minHeight: 56, borderRadius: 17, paddingHorizontal: 18, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 18 },
  primaryButtonText: { color: '#ffffff', fontSize: 15, fontWeight: '700' },
  footnote: { fontSize: 10, lineHeight: 16, textAlign: 'center', marginTop: 12 },
});
