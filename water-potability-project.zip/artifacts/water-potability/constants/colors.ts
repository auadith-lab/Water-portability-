/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#102a33',
    tint: '#087e8b',

    // Core surfaces
    background: '#f4f8f7',
    foreground: '#102a33',

    // Cards / elevated surfaces
    card: '#ffffff',
    cardForeground: '#102a33',

    // Primary action color (buttons, links, active states)
    primary: '#087e8b',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#e4f1ef',
    secondaryForeground: '#17454b',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#eaf1f0',
    mutedForeground: '#587176',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#d8efeb',
    accentForeground: '#14585c',

    // Destructive actions (delete, error states)
    destructive: '#b94c3d',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#d8e4e2',
    input: '#d8e4e2',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 16,
};

export default colors;
