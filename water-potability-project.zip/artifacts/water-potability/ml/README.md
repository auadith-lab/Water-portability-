# Random Forest model

`train_model.py` trains a scikit-learn Random Forest on the public Water
Potability dataset credited to Aditya Kadiwal, using the published CSV mirror
listed in the script. It median-imputes missing dataset values, evaluates a
stratified 20% holdout, and exports the trees for offline inference in the
mobile app.

From the repository root, run:

```sh
python3 artifacts/water-potability/ml/train_model.py
```

To train with another compatible CSV:

```sh
python3 artifacts/water-potability/ml/train_model.py --data /path/to/water_potability.csv
```

The input order is pH, Hardness, Solids, Chloramines, Sulfate, Conductivity,
Organic_carbon, Trihalomethanes, Turbidity; the target is `Potability` (0 or 1).
The probability shown by the app is the model's estimated probability for class
1. It is not a calibrated safety guarantee.
