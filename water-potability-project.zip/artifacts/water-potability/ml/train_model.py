#!/usr/bin/env python3
"""Train and export the on-device Random Forest used by Aqua / Check.

The bundled dataset is the public Kaggle water-potability dataset by Aditya
Kadiwal, mirrored in the MainakRepositor/Datasets GitHub repository.
"""

from __future__ import annotations

import argparse
import csv
import json
import urllib.request
from pathlib import Path

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, balanced_accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

DATA_URL = (
    "https://raw.githubusercontent.com/MainakRepositor/Datasets/master/"
    "water_potability.csv"
)
FEATURES = [
    "ph",
    "Hardness",
    "Solids",
    "Chloramines",
    "Sulfate",
    "Conductivity",
    "Organic_carbon",
    "Trihalomethanes",
    "Turbidity",
]
DEFAULT_OUTPUT = Path(__file__).resolve().parents[1] / "assets/models/water-random-forest.json"


def read_dataset(path: Path) -> tuple[np.ndarray, np.ndarray]:
    with path.open(newline="", encoding="utf-8") as csv_file:
        rows = csv.DictReader(csv_file)
        x_rows: list[list[float]] = []
        y_rows: list[int] = []
        for row in rows:
            x_rows.append(
                [float(row[name]) if row[name] else float("nan") for name in FEATURES]
            )
            y_rows.append(int(row["Potability"]))
    return np.asarray(x_rows), np.asarray(y_rows)


def serialize_tree(estimator: RandomForestClassifier) -> dict[str, list]:
    tree = estimator.tree_
    values = tree.value[:, 0, :].tolist()
    return {
        "left": tree.children_left.tolist(),
        "right": tree.children_right.tolist(),
        "feature": tree.feature.tolist(),
        "threshold": tree.threshold.tolist(),
        "values": values,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, help="Use a local CSV instead of downloading the public dataset.")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()

    dataset = args.data
    if dataset is None:
        dataset = Path("/tmp/water_potability.csv")
        request = urllib.request.Request(DATA_URL, headers={"User-Agent": "water-potability-app/1.0"})
        with urllib.request.urlopen(request, timeout=30) as response:
            dataset.write_bytes(response.read())

    features, target = read_dataset(dataset)
    x_train, x_test, y_train, y_test = train_test_split(
        features, target, test_size=0.2, random_state=42, stratify=target
    )

    pipeline = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            (
                "classifier",
                RandomForestClassifier(
                    n_estimators=72,
                    max_depth=12,
                    min_samples_leaf=4,
                    class_weight="balanced_subsample",
                    random_state=42,
                    n_jobs=-1,
                ),
            ),
        ]
    )
    pipeline.fit(x_train, y_train)
    predictions = pipeline.predict(x_test)
    classifier: RandomForestClassifier = pipeline.named_steps["classifier"]

    bundle = {
        "format_version": 1,
        "algorithm": "RandomForestClassifier",
        "features": FEATURES,
        "classes": [int(value) for value in classifier.classes_],
        "trees": [serialize_tree(tree) for tree in classifier.estimators_],
        "metrics": {
            "test_accuracy": round(float(accuracy_score(y_test, predictions)), 4),
            "test_balanced_accuracy": round(float(balanced_accuracy_score(y_test, predictions)), 4),
            "test_size": int(len(y_test)),
        },
        "imputation": "Per-feature training median",
        "source": "Kaggle Water Potability dataset by Aditya Kadiwal",
        "data_url": DATA_URL,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(bundle, separators=(",", ":")), encoding="utf-8")
    print(
        f"Exported {len(classifier.estimators_)} trees to {args.output} "
        f"(holdout accuracy {bundle['metrics']['test_accuracy']:.1%}; "
        f"balanced accuracy {bundle['metrics']['test_balanced_accuracy']:.1%})"
    )


if __name__ == "__main__":
    main()
